<?php
/**
 *
 * @author Francesco Borriello <infoborriello@gmail.com>
 * @company Vegan Solution
 * @package Vegan
 *
 */
namespace Vegan\Survey\Controller\Adminhtml\Chart;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\View\Result\PageFactory;
use Vegan\Survey\Helper\Cache;

class Upgradechart extends \Magento\Backend\App\Action{

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var Cache
     */
    protected $_cache;

    /**
     * @var ResultFactory
     */
    protected $_resultFactory;

    /**
     * Upgradechart constructor.
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param ResultFactory $resultFactory
     * @param Cache $cache
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        ResultFactory $resultFactory,
        Cache $cache
    ){
        $this->resultPageFactory = $resultPageFactory;
        $this->_cache = $cache;
        $this->_resultFactory = $resultFactory;
        parent::__construct($context);

    }

    /**
     * execute
     *
     * Clean cache and return in graph page
     *
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     */
    public function execute(){
        $this->_cache->delete(Cache::CACHE_ID);
        $resultRedirect = $this->_resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }
}