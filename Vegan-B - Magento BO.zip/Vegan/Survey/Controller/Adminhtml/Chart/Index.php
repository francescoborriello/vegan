<?php
/**
 *
 * @author Francesco Borriello <infoborriello@gmail.com>
 * @company Vegan Solution
 * @package Vegan
 *
 */
namespace Vegan\Survey\Controller\Adminhtml\Chart;

use Vegan\Survey\Controller\Adminhtml\Data;

class Index extends Data
{
    /**
     *
     * execute
     *
     * Rendering template
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        return $this->resultPageFactory->create();
    }
}
