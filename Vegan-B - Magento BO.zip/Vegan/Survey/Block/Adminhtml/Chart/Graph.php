<?php
/**
 *
 * @author Francesco Borriello <infoborriello@gmail.com>
 * @company Vegan Solution
 * @package Vegan
 *
 */
namespace Vegan\Survey\Block\Adminhtml\Chart;


use Magento\Backend\Block\Template\Context;
use Vegan\Survey\Api\Data\DataInterface;
use \Vegan\Survey\Helper\Cache;
use Magento\Backend\Model\UrlInterface;
use Vegan\Survey\Model\ResourceModel\Data\CollectionFactory;

class Graph extends \Magento\Backend\Block\Template{

    const REFRESHURL = 'survey/chart/upgradechart';
    /**
     * @var Cache
     */
    protected $_cache;

    /**
     * @var UrlInterface
     */
    protected $_urlInterface;

    /**
     * @var CollectionFactory
     */
    protected $_collectionFactory;

    public function __construct(Context $context, Cache $cache, CollectionFactory $collectionFactory, UrlInterface $urlInterface, array $data = []){
        $this->_cache = $cache;
        $this->_collectionFactory = $collectionFactory;
        $this->_urlInterface = $urlInterface;
        parent::__construct($context, $data);
    }

    /**
     *
     * getButtonHtml
     *
     * Generate cache button upgrade
     *
     * @return string
     */
    public function getButtonHtml(){
        $url = $this->_urlInterface->getUrl(
            self::REFRESHURL
        );
        $button = $this->getLayout()->createBlock(
            'Magento\Backend\Block\Widget\Button'
        )->setData(
            [
                'id' => 'update_graph',
                'label' => __('Update Graph'),
                'on_click' => sprintf("location.href = '%s';", $url),
                'class' => 'back'
            ]
        );

        return $button->toHtml();
    }

    /**
     * getLabels
     *
     * Get labels to send in magento-init for graph
     *
     * @return array
     */
    public function getLabels(){
        $cacheLabels = $this->_cache->load(Cache::CACHE_ID_LABELS);
        if(!$cacheLabels){
            $label = ["Answer 1", "Answer 2", "Answer 3"];
            $this->_cache->save(serialize($label), Cache::CACHE_ID_LABELS);
        }else{
            $label = unserialize($cacheLabels);
        }
        return $label;
    }

    /**
     *
     * getDataSets
     *
     * Get data to send in magento-init for graph
     *
     * @return array
     */
    public function getDataSets(){
        $cacheDataSets = $this->_cache->load(Cache::CACHE_ID_DATASETS);
        if(!$cacheDataSets){
            $dataSets = [
                [
                    "minBarLength" => 0,
                    "label" => self::YES,
                    "data" => [
                        $this->_getCountResponseByAnswer(  DataInterface::DATA_ANSWER1, self::YES),
                        $this->_getCountResponseByAnswer(DataInterface::DATA_ANSWER2, self::YES),
                        $this->_getCountResponseByAnswer(DataInterface::DATA_ANSWER3, self::YES)
                    ],
                    "fill" => true,
                    "backgroundColor" => "green",
                ],
                [
                    "minBarLength" => 0,
                    "label" => self::NO,
                    "data" => [
                        $this->_getCountResponseByAnswer(DataInterface::DATA_ANSWER1, self::NO),
                        $this->_getCountResponseByAnswer(DataInterface::DATA_ANSWER2, self::NO),
                        $this->_getCountResponseByAnswer(DataInterface::DATA_ANSWER3, self::NO)
                    ],
                    "fill" => true,
                    "backgroundColor" => "rgb(75, 192, 192)",
                ],

            ];
            $this->_cache->save(serialize($dataSets), Cache::CACHE_ID_DATASETS);
        }else{
            $dataSets = unserialize($cacheDataSets);
        }
        return $dataSets;
    }

    private function _getCountResponseByAnswer($item, $condition){
        return $this->_collectionFactory->create()->addFieldToFilter($item, $condition)->count();
    }


}