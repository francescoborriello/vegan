<?php
/**
 *
 * @author Francesco Borriello <infoborriello@gmail.com>
 * @company Vegan Solution
 * @package Vegan
 *
 */
namespace Vegan\Survey\Api\Data;

interface DataInterface{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */
    const DATA_ID = 'id';
    const DATA_REFERENCE = 'reference';
    const DATA_ANSWER1 = 'answer_1';
    const DATA_ANSWER2 = 'answer_2';
    const DATA_ANSWER3 = 'answer_3';


    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Set ID
     *
     * @param $id
     * @return DataInterface
     */
    public function setId($id);

    /**
     * Get Data Title
     *
     * @return string
     */
    public function getReference();

    /**
     * Set Data Title
     *
     * @param $title
     * @return mixed
     */
    public function setReference($reference);

    /**
     * Get Data Description
     *
     * @return mixed
     */
    public function getAnswer1();

    /**
     * Set Data Description
     *
     * @param $description
     * @return mixed
     */
    public function setAnswer1($answer);

    /**
     * Get Data Description
     *
     * @return mixed
     */
    public function getAnswer2();

    /**
     * Set Data Description
     *
     * @param $description
     * @return mixed
     */
    public function setAnswer2($answer);

    /**
     * Get Data Description
     *
     * @return mixed
     */
    public function getAnswer3();

    /**
     * Set Data Description
     *
     * @param $description
     * @return mixed
     */
    public function setAnswer3($answer);
}
