var config = {
    map: {
        '*': {
            chart: 'Vegan_Survey/js/chart',
            logger: 'Vegan_Survey/js/logger',
            customjs: 'Vegan_Survey/js/custom'
        }
    },
    shim:
        {
            chart : ['jquery'],
            customjs: ['jquery','chart','logger']
        },

}