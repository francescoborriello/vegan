define([
    "jquery",
    "logger",
    "chart",
    "mage/mage"
], function ($,
             logger,
             chart,
             mage) {
    "use strict";

    $.widget('custom.graph', {
        dataSets: [],
        labels: [],

        _create: function () {
            self = this;

            this.dataSets = this.options.datasets;
            this.labels = this.options.labels;
            this.initChart();


        },

        initChart: function () {
            self = this;
            new Chart(this.element, {
                "type": "bar",
                "data": {
                    "labels": self.labels,
                    "datasets": self.dataSets
                },
                "options": {
                    "scales": {
                        "yAxes": [
                            {
                                "ticks": {
                                    "beginAtZero": true,
                                    "min": 0,
                                    "stepSize": 1,
                                }
                            }
                        ]
                    }
                }
            });
            Chart.platform.disableCSSInjection = true;

            this.bindClickElements();
        },

        bindClickElements: function () {
            self = this;
            this.element.on('click', function (e) {
                logger.log("You click on element: " + e.target);
            });
        }
    });

    return $.custom.graph;
});
