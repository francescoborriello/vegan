<?php
/*
 * Vegan_Survey

 * @category   Vegan
 * @package    Vegan_Survey
 * @copyright  Copyright (c) 2019 Scott Parsons
 * @license    https://github.com/ScottParsons/module-sampleuicomponent/blob/master/LICENSE.md
 * @version    1.1.2
 */
namespace Vegan\Survey\Model\Data\Source;

use Magento\Framework\Data\OptionSourceInterface;

class Status implements OptionSourceInterface
{
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 1, 'label' => __('YES')],
            ['value' => 0, 'label' => __('NO')]
        ];
    }
}
