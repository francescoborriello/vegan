<?php
/**
 *
 * @author Francesco Borriello <infoborriello@gmail.com>
 * @company Vegan Solution
 * @package Vegan
 *
 */
namespace Vegan\Survey\Model\Select\Source;

class Options implements \Magento\Framework\Option\ArrayInterface{
    /**
     * Options for Type
     *
     * @return array
     */
    public function toOptionArray(){
        return [
            ['value' => 1, 'label' => __('YES')],
            ['value' => 0, 'label' => __('NO')]
        ];
    }
}