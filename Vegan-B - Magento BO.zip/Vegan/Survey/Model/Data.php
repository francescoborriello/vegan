<?php
/**
 *
 * @author Francesco Borriello <infoborriello@gmail.com>
 * @company Vegan Solution
 * @package Vegan
 *
 */
namespace Vegan\Survey\Model;

use Magento\Framework\Model\AbstractModel;
use Vegan\Survey\Api\Data\DataInterface;

class Data extends AbstractModel implements DataInterface{

    /**
     * Cache tag
     */
    const CACHE_TAG = 'vegan_survey_data';

    /**
     * Initialise resource model
     * @codingStandardsIgnoreStart
     */
    protected function _construct(){
        // @codingStandardsIgnoreEnd
        $this->_init('Vegan\Survey\Model\ResourceModel\Data');
    }

    /**
     * Get cache identities
     *
     * @return array
     */
    public function getIdentities(){
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Get reference
     *
     * @return string
     */
    public function getReference(){
        return $this->getData(DataInterface::DATA_REFERENCE);
    }

    /**
     * Set reference
     *
     * @param $reference
     * @return $this
     */
    public function setReference($reference){
        return $this->setData(DataInterface::DATA_REFERENCE, $reference);
    }

    /**
     * Get answer1
     *
     * @return string
     */
    public function getAnswer1(){
        return $this->getData(DataInterface::DATA_ANSWER1);
    }

    /**
     * Set answer1
     *
     * @param $answer
     * @return $this
     */
    public function setAnswer1($answer){
        return $this->setData(DataInterface::DATA_ANSWER1, $answer);
    }

    /**
     * Get answer2
     *
     * @return string
     */
    public function getAnswer2(){
        return $this->getData(DataInterface::DATA_ANSWER2);
    }

    /**
     * Set answer2
     *
     * @param $answer
     * @return $this
     */
    public function setAnswer2($answer){
        return $this->setData(DataInterface::DATA_ANSWER2, $answer);
    }

    /**
     * Get answer3
     *
     * @return string
     */
    public function getAnswer3(){
        return $this->getData(DataInterface::DATA_ANSWER3);
    }

    /**
     * Set answer3
     *
     * @param $answer
     * @return $this
     */
    public function setAnswer3($answer){
        return $this->setData(DataInterface::DATA_ANSWER3, $answer);
    }


}
