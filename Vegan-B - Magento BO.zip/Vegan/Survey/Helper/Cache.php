<?php
/**
 *
 * @author Francesco Borriello <infoborriello@gmail.com>
 * @company Vegan Solution
 * @package Vegan
 *
 */
namespace Vegan\Survey\Helper;


use Magento\Framework\App\Cache\State;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use \Magento\Framework\App\Cache as AppCache;

class Cache extends AbstractHelper{


    const CACHE_ID_LABELS = 'graph_labels';
    const CACHE_ID_DATASETS = 'graph_datasets';


    /**
     * Cache type code unique among all cache types
     */
    const CACHE_ID = 'vegan_survey';

    /**
     * Cache tag used to distinguish the cache type from all other cache
     */
    const CACHE_TAG = 'SURVEY';

    const CACHE_LIFETIME = 86400;

    protected $_cache;
    protected $_state;
    protected $_typeList;

    public function __construct(Context $context, AppCache $cache, State $state, AppCache\TypeListInterface $typeList){
        $this->_state = $state;
        $this->_cache = $cache;
        $this->_typeList = $typeList;
        parent::__construct($context);
    }

    public function load($cacheId){
        if($this->_state->isEnabled(self::CACHE_ID)){
            return $this->_cache->load($cacheId);
        }
        return false;
    }

    public function save($data, $cacheId, $cacheLifeTime = self::CACHE_LIFETIME){
        if($this->_state->isEnabled(self::CACHE_ID)){
            return $this->_cache->save($data, $cacheId, [self::CACHE_TAG], $cacheLifeTime);
        }
        return false;
    }

    public function clean(){
        if($this->_state->isEnabled(self::CACHE_ID)){
            return $this->_typeList->cleanType(self::CACHE_ID);
        }
        return false;
    }

    public function delete($cacheId){
        if($this->_state->isEnabled(self::CACHE_ID)){
            return $this->_cache->remove($cacheId);
        }
        return false;
    }
}