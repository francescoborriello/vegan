<?php
/**
 *
 * @author Francesco Borriello <infoborriello@gmail.com>
 * @company Vegan Solution
 * @package Vegan
 *
 */
namespace Vegan\Survey\Observer;


use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Vegan\Survey\Helper\Cache;

class CleanCache implements ObserverInterface{


    /**
     * @var Cache $_cache
     */
    protected $_cache;

    /**
     * CleanCache constructor.
     * @param Cache $cache
     */
    public function __construct(Cache $cache){
        $this->_cache = $cache;
    }


    /**
     *
     * Manage cache
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer){
        switch($observer->getData('cache_type')){
            case Cache::CACHE_ID_LABELS:
                $this->_cache->delete(Cache::CACHE_ID_LABELS);
                break;
            case Cache::CACHE_ID_DATASETS:
                $this->_cache->delete(Cache::CACHE_ID_DATASETS);
                break;
            default:
                $this->_cache->delete(Cache::CACHE_ID_DATASETS);
                $this->_cache->delete(Cache::CACHE_ID_LABELS);
                break;
        }

    }
}